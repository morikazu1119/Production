﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Runtime.InteropServices;
using System.Diagnostics.Tracing;

namespace osero2
{
    //オセロのアルゴリズムは　https://lets-csharp.com/c-sharp-de-othello/　を参考（バグあり）　=>　Arduinoで操作できるように改良
    //上記のURLのコードには、相手の石がある場所に、自身の石を置けるバグあり　=>　修正済み
    //オセロAI：ランダム選択　=>　評価値による選択
    //評価値の表は https://kemako.github.io/othello_kemako/　を参考　=>　実装済み
    //ArduinoとVisualStudioの接続　=>　接続確認済み

    public partial class Form1 : Form
    {
        [DllImport("user32.dll", SetLastError = true)]
        
        //マウス操作をコード内で可能にする
        public static extern void mouse_event(int dwFlags, int dx, int dy, int dwData, int dwExtraInfo);
        private const int MOUSEEVENTF_LEFTDOWN = 0x02;
        private const int MOUSEEVENTF_LEFTUP = 0x04;

        //ポートに用いる変数
        string[] port;
        public string str;

        //初期のマウス座標
        int mouse_x=300;
        int mouse_y=300;

        //AIに与える評価値の表 序盤、中盤、終盤に分かれている。
        int[,] start = { {30,-12,-1,-2,-2,-1,-12,30},
                         {-12,-15,-3,-3,-3,-3,-15,-12},
                         {-1,-3,-1,-2,-2,-1,-3,-1},
                         {-2,-3,-2,1,1,-2,-3,-2},
                         {-2,-3,-2,1,1,-2,-3,-2},
                         {-1,-3,-1,-2,-2,-1,-3,-1},
                         {-12,-15,-3,-3,-3,-3,-15,-12},
                         {30,-12,-1,-2,-2,-1,-12,30},
                        };

        int[,] middle = {{80,-22,0,-1,-1,0,-22,80},
                         {-22,-25,-3,-3,-3,-3,-25,-22},
                         {0,-3,0,-1,-1,0,-3,0 },
                         {-1,-3,-1,0,0,-1,-3,-1 },
                         {-1,-3,-1,0,0,-1,-3,-1 },
                         {0,-3,0,-1,-1,0,-3,0 },
                         {-22,-25,-3,-3,-3,-3,-25,-22},
                         {80,-22,0,-1,-1,0,-22,80},
                         };

        int[,] end = { {15,-3,1,1,1,1,-3,15},
                       {-3,-3,1,1,1,1,-3,-3},
                       {1,1,1,1,1,1,1,1 },
                       {1,1,1,1,1,1,1,1 },
                       {1,1,1,1,1,1,1,1 },
                       {1,1,1,1,1,1,1,1 },
                       {-3,-3,1,1,1,1,-3,-3},
                       {15,-3,1,1,1,1,-3,15},
                      };

        //ゲームボード上の左上の座標
        Point leftTopPoint = new Point(30, 30);
        //8x8のマスに対応している
        Stone[,] StonePosition = new Stone[8, 8];
        //自分番ではTrue,相手の番ではFalse
        bool myturn = false;

        public Form1()
        {
            InitializeComponent();
            Osero();
            Setting();
            Mouse_move(mouse_x, mouse_y);
            //pictureBox1.Parent = this;
        }
        
        public void Setting() //VisualStudio と Arduino の接続
        {
            serialPort1.BaudRate = 9600;
            port = SerialPort.GetPortNames();
            if (port.Length > 0)
            {
                serialPort1.PortName = port[0];
                serialPort1.Open();
                serialPort1.DataReceived += serialPort1_DataReceived;
            }
          
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e) //Arduinoからの受信
        {

            if (port.Length > 0)
            {
                str = serialPort1.ReadLine();
                if (this.InvokeRequired)
                {
                    this.Invoke(new EventHandler(Show));
                }
                else
                {
                    Show(this, EventArgs.Empty);
                }
            }
            

        }

        private void Show(object sender, EventArgs e)
        {
            //デバック用
            //textBox1に受信したデータを表示する
            //textBox1.SelectionLength = 0;
            //textBox1.SelectedText = str + "\r\n";
            //文字列型で条件分岐を行うと都合が悪いため、整数型に変換を行う
            int num = int.Parse(str);

            //条件によるマウス座標の移動
            switch (num)
            {
                case 3:
                    mouse_y -= 20;
                    Mouse_move(mouse_x, mouse_y);
                    break;
                case 4:
                    mouse_y += 20;
                    Mouse_move(mouse_x, mouse_y);
                    break;
                case 1:
                    mouse_x += 20;
                    Mouse_move(mouse_x, mouse_y);
                    break;
                case 2:
                    mouse_x -= 20;
                    Mouse_move(mouse_x, mouse_y);
                    break;
                case 5:
                    mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
                    break;
            }
        }

        void Mouse_move(int X,int Y) //マウスを座標を変えるメソッド
        {
            Cursor.Position = new Point(X, Y);
        }

        
        void Osero() //オセロボードの作製
        {
            for (int row = 0; row < 8; row++)
            {
                for (int colum = 0; colum < 8; colum++)
                {
                    Stone stone = new Stone(colum, row);
                    stone.Parent = this;
                    //1マスのサイズ
                    stone.Size = new Size(40, 40);
                    //マス間の分け方
                    stone.BorderStyle = BorderStyle.FixedSingle;
                    //マス配置座標
                    stone.Location = new Point(leftTopPoint.X + colum * 40, leftTopPoint.Y + row * 40);
                    //StonePositionにstoneを置く
                    StonePosition[colum, row] = stone;
                    //stone.StoenClickにBox_PictureBoxExClickメソッドを追加する => 各マスにクリックしたときの動作を追加する
                    stone.StoneClick += Box_PictureBoxExClick;
                    //デフォルトは何もないから緑色
                    stone.BackColor = Color.Green;
                }
            }
        }


        
        void Start() //ゲームスタート時の処理
        {
            //pictureBox1.Image = null;
            //Stoneオブジェクトのコレクションをstonesに格納
            var stones = StonePosition.Cast<Stone>();
            //Stoneオブジェクトにアクセスし、StoneColorプロパティをNoneにする
            foreach (Stone stone in stones)
                stone.StoneColor = StoneColor.None;

            //最初の白x2, 黒x2のコマを用意する
            StonePosition[3, 3].StoneColor = StoneColor.Black;
            StonePosition[4, 4].StoneColor = StoneColor.Black;

            StonePosition[3, 4].StoneColor = StoneColor.White;
            StonePosition[4, 3].StoneColor = StoneColor.White;

            myturn = true;
            textBox2.Text = "あなたの番です。";
            if (port.Length > 0)
            {
                serialPort1.WriteLine("7");
            }
                
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Start();
        }

        async private void Box_PictureBoxExClick(int x, int y)
        {
            // 自分の手番か確認する
            if (!myturn)
                return;

            // 着手可能な場所か調べる
            List<Stone> stones = CountReverse(x, y, StoneColor.Black);

            //クリックした石の座標を取得する
            var stone = StonePosition[x, y]; 

            // 着手可能であれば石を置き、挟んだ石をひっくり返す
            if ((stones.Count != 0) && (stone.StoneColor == StoneColor.None))
            {
                //StonePosition[x,y]に黒い石を置く
                StonePosition[x, y].StoneColor = StoneColor.Black;
                //stonesの各要素StoneColor => StoneColor.Black
                stones.Select(xx => xx.StoneColor = StoneColor.Black).ToList();

                myturn = false;

                textBox2.Text = "コンピュータが考えています";
                if (port.Length > 0)
                {
                    serialPort1.WriteLine("6");
                }
               
                await Task.Delay(1000);

                EnemyThink();
            }
            else
                textBox2.Text = "ここには打てません";
        }

        //コンピュータ側の処理
        void EnemyThink()
        {
            bool Compass = false;
            bool Youpass = false;
            while (true)
            {
                // Cast メソッドで 1次元に
                var stones = StonePosition.Cast<Stone>();

                // 石が置かれていない場所で挟むことができる場所を探す。
                stones = stones.Where(xx => xx.StoneColor == StoneColor.None && CountReverse(xx.Colum, xx.Row, StoneColor.White).Any());
                
                var hands = stones.ToList();
                int count = hands.Count();
                int max_score = -3000;
                int[] position = new int[2];
                //textBox1.Text = count.ToString();

                //AIが最適な場所を見つける
                if (count > 0)
                {
                    int none = stones.Count(stone => stone.StoneColor == StoneColor.None);
                    //置ける石の評価値を確認し、最も評価値の高い場所に配置を行う。

                    if (none >= 35)
                    {
                        foreach (var h in stones)
                        {
                            if (start[h.Colum, h.Row] >= max_score)
                            {
                                max_score = start[h.Colum, h.Row];
                                position[0] = h.Colum;
                                position[1] = h.Row;
                            }

                        }
                    }
                    else if ((none >= 20)&&(none < 35))
                    {
                        foreach (var h in stones)
                        {
                            if (middle[h.Colum, h.Row] >= max_score)
                            {
                                max_score = middle[h.Colum, h.Row];
                                position[0] = h.Colum;
                                position[1] = h.Row;
                            }

                        }
                    }
                    else
                    {
                        foreach (var h in stones)
                        {
                            if (end[h.Colum, h.Row] >= max_score)
                            {
                                max_score = end[h.Colum, h.Row];
                                position[0] = h.Colum;
                                position[1] = h.Row;
                            }

                        }
                    }

                    // 石を置いてひっくり返す
                    StonePosition[position[0], position[1]].StoneColor = StoneColor.White;
                    List<Stone> stones1 = CountReverse(position[0], position[1], StoneColor.White);
                    stones1.Select(xx => xx.StoneColor = StoneColor.White).ToList();
                }
                else
                {
                    if (Youpass)
                    {
                        // 「手」が存在しない場合はゲームセット
                        Gameset();
                        return;
                    }

                    // 石をおける場所が見つからない場合はパス
                    Compass = true;
                }

                //「手」は存在するのか
                stones = StonePosition.Cast<Stone>();
                stones = stones.Where(xx => (xx.StoneColor == StoneColor.None) && CountReverse(xx.Colum, xx.Row, StoneColor.Black).Any());
                count = stones.ToList().Count();

                // 「手」が存在するならプレーヤーの番とする
                if (count > 0)
                {
                    myturn = true;
                    if (Compass)
                    {
                        textBox2.Text = "コンピュータはパスしました。あなたの番です。";
                        if (port.Length > 0)
                        {
                            serialPort1.WriteLine("7");
                        }
                            
                    }
                    else
                    {
                        textBox2.Text = "あなたの番です。";
                        if (port.Length > 0)
                        {
                            serialPort1.WriteLine("7");
                        }
                    }                        
                    return;
                }
                else
                {
                    // 「手」が存在しない場合はもう一度コンピュータの番
                    if (!Compass)
                    {
                        Youpass = true;
                        textBox2.Text = "あなたの番ですが手がありません";
                    }
                    else
                    {
                        //「手」が存在しない場合はゲームセット
                        Gameset();
                        return;
                    }
                }
            }
        }

        //ゲーム終了時の処理
        void Gameset()
        {
            var stones = StonePosition.Cast<Stone>();

            //黒白の石の数をカウント
            int blackCount = stones.Count(xx => xx.StoneColor == StoneColor.Black);
            int whiteCount = stones.Count(xx => xx.StoneColor == StoneColor.White);

            string str = "";
            if (blackCount != whiteCount)
            {
                string winner;
                if (blackCount > whiteCount)
                {
                    winner = "黒";
                }
                else
                {
                    winner = "白";
                }
                
                str = String.Format("終局しました。{0} 対 {1} で {2} の勝ちです。", blackCount, whiteCount, winner);
                if (winner == "黒")
                {
                    if (port.Length > 0)
                    {
                        serialPort1.WriteLine("8");
                    }
                }
            }
            else
            {
                str = String.Format("終局しました。{0} 対 {1} で 引き分けです。", blackCount, whiteCount);
            }
            textBox2.Text = str;
            return;
        }

        //石が挟まれた時の処理
        List<Stone> CountReverse(int x, int y, StoneColor stoneColor)
        {
            List<Stone> stones = new List<Stone>();
            stones.AddRange(PutUp(x, y, stoneColor)); // 上方向に挟めているものを取得
            stones.AddRange(PutDown(x, y, stoneColor)); // 下
            stones.AddRange(PutLeft(x, y, stoneColor)); // 左
            stones.AddRange(PutRight(x, y, stoneColor)); // 右
            stones.AddRange(PutLeftTop(x, y, stoneColor)); // 左上
            stones.AddRange(PutLeftDown(x, y, stoneColor)); // 左下
            stones.AddRange(PutRightTop(x, y, stoneColor)); // 右上
            stones.AddRange(PutRightDown(x, y, stoneColor)); // 右下

            return stones;
        }

        //参考コードには問題があり、以下の上下左右斜めの判定が間違っているため、相手の石の上に自分の石をおけるバグがおきる。
        //石を置けるのは、石の色が緑（背景）であるときのみ置けるようにすることでバグを回避
        List<Stone> PutUp(int x, int y, StoneColor color)
        {
            List<Stone> stones = new List<Stone>();
            StoneColor enemyColor = StoneColor.None;
            if (color == StoneColor.Black)
                enemyColor = StoneColor.White;
            else
                enemyColor = StoneColor.Black;

            //上方向にはこれ以上挟めない
            if (y - 1 < 0)
                return stones;

            //置いた石が上方向に同じ色もしくは、色なしの場合、置いた石だけを返す
            var s = StonePosition[x, y - 1];
            if (s.StoneColor == color || s.StoneColor == StoneColor.None)
                return stones;

            //stonesにsを追加
            stones.Add(s);

            for (int i = 0; ; i++)
            {
                if (y - 1 - i < 0)
                    return new List<Stone>();

                var s1 = StonePosition[x, y - 1 - i];
                //上の石が相手の石の時
                if (s1.StoneColor == enemyColor)
                {
                    stones.Add(s1);
                    continue;
                }
                //上の石が相手の石で自身の石で最後に挟まれていた場合
                if (s1.StoneColor == color)
                    return stones;
                //上の石が相手の石で自身の石で挟まれていない場合
                if (s1.StoneColor == StoneColor.None)
                    return new List<Stone>();
            }
        }//上

        List<Stone> PutDown(int x, int y, StoneColor color)
        {
            List<Stone> stones = new List<Stone>();
            StoneColor enemyColor = StoneColor.None;
            if (color == StoneColor.Black)
                enemyColor = StoneColor.White;
            else
                enemyColor = StoneColor.Black;

            if (y + 1 > 7)
                return stones;

            var s = StonePosition[x, y + 1];
            if (s.StoneColor == color || s.StoneColor == StoneColor.None)
                return stones;

            stones.Add(s);

            for (int i = 0; ; i++)
            {
                if (y + 1 + i > 7)
                    return new List<Stone>();

                var s1 = StonePosition[x, y + 1 + i];
                if (s1.StoneColor == enemyColor)
                {
                    stones.Add(s1);
                    continue;
                }
                if (s1.StoneColor == color)
                    return stones;
                if (s1.StoneColor == StoneColor.None)
                    return new List<Stone>();
            }
        }//下

        List<Stone> PutLeft(int x, int y, StoneColor color)
        {
            List<Stone> stones = new List<Stone>();
            StoneColor enemyColor = StoneColor.None;
            if (color == StoneColor.Black)
                enemyColor = StoneColor.White;
            else
                enemyColor = StoneColor.Black;

            if (x - 1 < 0)
                return stones;

            var s = StonePosition[x - 1, y];
            if (s.StoneColor == color || s.StoneColor == StoneColor.None)
                return stones;

            stones.Add(s);

            for (int i = 0; ; i++)
            {
                if (x - 1 - i < 0)
                    return new List<Stone>();

                var s1 = StonePosition[x - 1 - i, y];
                if (s1.StoneColor == enemyColor)
                {
                    stones.Add(s1);
                    continue;
                }
                if (s1.StoneColor == color)
                    return stones;
                if (s1.StoneColor == StoneColor.None)
                    return new List<Stone>();
            }
        }//左

        List<Stone> PutRight(int x, int y, StoneColor color)
        {
            List<Stone> stones = new List<Stone>();
            StoneColor enemyColor = StoneColor.None;
            if (color == StoneColor.Black)
                enemyColor = StoneColor.White;
            else
                enemyColor = StoneColor.Black;

            if (x + 1 > 7)
                return stones;

            var s = StonePosition[x + 1, y];
            if (s.StoneColor == color || s.StoneColor == StoneColor.None)
                return stones;

            stones.Add(s);

            for (int i = 0; ; i++)
            {
                if (x + 1 + i > 7)
                    return new List<Stone>();

                var s1 = StonePosition[x + 1 + i, y];
                if (s1.StoneColor == enemyColor)
                {
                    stones.Add(s1);
                    continue;
                }
                if (s1.StoneColor == color)
                    return stones;
                if (s1.StoneColor == StoneColor.None)
                    return new List<Stone>();
            }
        }//右

        List<Stone> PutLeftTop(int x, int y, StoneColor color)
        {
            List<Stone> stones = new List<Stone>();
            StoneColor enemyColor = StoneColor.None;
            if (color == StoneColor.Black)
                enemyColor = StoneColor.White;
            else
                enemyColor = StoneColor.Black;

            if (x - 1 < 0)
                return stones;
            if (y - 1 < 0)
                return stones;

            var s = StonePosition[x - 1, y - 1];
            if (s.StoneColor == color || s.StoneColor == StoneColor.None)
                return stones;

            stones.Add(s);

            for (int i = 0; ; i++)
            {
                if (x - 1 - i < 0)
                    return new List<Stone>();

                if (y - 1 - i < 0)
                    return new List<Stone>();

                var s1 = StonePosition[x - 1 - i, y - 1 - i];
                if (s1.StoneColor == enemyColor)
                {
                    stones.Add(s1);
                    continue;
                }
                if (s1.StoneColor == color)
                    return stones;

                if (s1.StoneColor == StoneColor.None)
                    return new List<Stone>();
            }
        }//左上

        List<Stone> PutRightTop(int x, int y, StoneColor color)
        {
            List<Stone> stones = new List<Stone>();
            StoneColor enemyColor = StoneColor.None;
            if (color == StoneColor.Black)
                enemyColor = StoneColor.White;
            else
                enemyColor = StoneColor.Black;

            if (x + 1 > 7)
                return stones;
            if (y - 1 < 0)
                return stones;

            var s = StonePosition[x + 1, y - 1];
            if (s.StoneColor == color || s.StoneColor == StoneColor.None)
                return stones;

            stones.Add(s);

            for (int i = 0; ; i++)
            {
                if (x + 1 + i > 7)
                    return new List<Stone>();

                if (y - 1 - i < 0)
                    return new List<Stone>();

                var s1 = StonePosition[x + 1 + i, y - 1 - i];
                if (s1.StoneColor == enemyColor)
                {
                    stones.Add(s1);
                    continue;
                }
                if (s1.StoneColor == color)
                    return stones;

                if (s1.StoneColor == StoneColor.None)
                    return new List<Stone>();
            }
        }//右上

        List<Stone> PutRightDown(int x, int y, StoneColor color)
        {
            List<Stone> stones = new List<Stone>();
            StoneColor enemyColor = StoneColor.None;
            if (color == StoneColor.Black)
                enemyColor = StoneColor.White;
            else
                enemyColor = StoneColor.Black;

            if (x + 1 > 7)
                return stones;
            if (y + 1 > 7)
                return stones;

            var s = StonePosition[x + 1, y + 1];
            if (s.StoneColor == color || s.StoneColor == StoneColor.None)
                return stones;

            stones.Add(s);

            for (int i = 0; ; i++)
            {
                if (x + 1 + i > 7)
                    return new List<Stone>();

                if (y + 1 + i > 7)
                    return new List<Stone>();

                var s1 = StonePosition[x + 1 + i, y + 1 + i];
                if (s1.StoneColor == enemyColor)
                {
                    stones.Add(s1);
                    continue;
                }
                if (s1.StoneColor == color)
                    return stones;

                if (s1.StoneColor == StoneColor.None)
                    return new List<Stone>();
            }
        }//右下

        List<Stone> PutLeftDown(int x, int y, StoneColor color)
        {
            List<Stone> stones = new List<Stone>();
            StoneColor enemyColor = StoneColor.None;
            if (color == StoneColor.Black)
                enemyColor = StoneColor.White;
            else
                enemyColor = StoneColor.Black;

            if (x - 1 < 0)
                return stones;
            if (y + 1 > 7)
                return stones;

            var s = StonePosition[x - 1, y + 1];
            if (s.StoneColor == color || s.StoneColor == StoneColor.None)
                return stones;

            stones.Add(s);

            for (int i = 0; ; i++)
            {
                if (x - 1 - i < 0)
                    return new List<Stone>();

                if (y + 1 + i > 7)
                    return new List<Stone>();

                var s1 = StonePosition[x - 1 - i, y + 1 + i];
                if (s1.StoneColor == enemyColor)
                {
                    stones.Add(s1);
                    continue;
                }
                if (s1.StoneColor == color)
                    return stones;

                if (s1.StoneColor == StoneColor.None)
                    return new List<Stone>();
            }
        }//左下


    }

    public class Stone : PictureBox
    {
        //石の色を表すStoneColorを取得設定
        StoneColor stoneColor = StoneColor.None;

        //石の列
        public int Colum { get; set; } = 0;
        public int Row { get; set; } = 0;

        //コンストラクタ
        //Colum, Rowプロパティを初期化
        public Stone(int colum, int row)
        {
            Colum = colum;
            Row = row;

            //クリックイベントが起きたとき
            //Arduino側からボタン操作を可能にする必要あり
            Click += Stone_Click;
        }

        public delegate void StoneClickHandler(int x, int y);
        public event StoneClickHandler StoneClick;

        private void Stone_Click(object sender, EventArgs e)
        {
            StoneClick?.Invoke(Colum, Row);
        }

        //石の色
        public StoneColor StoneColor
        {
            get { return stoneColor; }
            set
            {
                SizeMode = PictureBoxSizeMode.StretchImage;

                stoneColor = value;
                if (value == StoneColor.Black)
                    Image = Properties.Resources.black;
                if (value == StoneColor.White)
                    Image = Properties.Resources.white;
                if (value == StoneColor.None)
                    Image = null;
            }
        }
    }
    //石の色の番号
    public enum StoneColor
    {
        None = 0,
        Black = 1,
        White = 2,
    }


}
